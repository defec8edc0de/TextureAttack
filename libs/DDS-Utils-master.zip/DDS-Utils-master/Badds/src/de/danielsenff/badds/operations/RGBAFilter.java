/**
 * 
 */
package de.danielsenff.badds.operations;

/**
 * @author danielsenff
 *
 */
public interface RGBAFilter {
	public int[] filterRGB(int x, int y, int[] rgba);
}
