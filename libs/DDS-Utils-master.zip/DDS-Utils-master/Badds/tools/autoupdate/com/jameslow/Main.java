package com.jameslow;

import java.util.logging.Logger;

/**
 * Dummy Main to compile XMLHelper for ant task
 */
public class Main {
	public static Logger Logger() {
		return null;
	}
}
