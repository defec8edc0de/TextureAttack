package de.danielsenff.madds.models;

public enum Material {
	Diffuse, Specular, Normal, Other, Animation
}
