/**
 * 
 */
package de.danielsenff.radds.models;

/**
 * @author danielsenff
 *
 */
public class LoadImageException extends Exception {

}
