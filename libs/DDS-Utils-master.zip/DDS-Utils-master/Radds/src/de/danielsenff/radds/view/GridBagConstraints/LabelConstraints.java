package de.danielsenff.radds.view.GridBagConstraints;

import java.awt.Insets;

/*
 * ### Not yet documented. ###
 * @author Jake Miles
 */

public class LabelConstraints extends GBConstraints {

    public LabelConstraints () {
        super (1, 1, NONE, NORTHEAST, new Insets (5, 5, 5, 2));
    }

}
